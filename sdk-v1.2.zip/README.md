# PGREWARDS-PHP-SDK
This SDK has been developed for the PGRewards platform
Nobody is responsible for the use you will make of this sdk. The user of this SDK is solely responsible for his actions.
